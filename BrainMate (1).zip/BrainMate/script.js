
function searchAlgo(subject) {
    const output = document.getElementById("output");
    output.innerHTML = `<h3>Searching for ${subject} content...</h3>`;

    // Simulate an algorithm (like linear search)
    const topics = {
        "Maths": ["Algebra", "Calculus", "Geometry"],
        "Physics": ["Motion", "Forces", "Waves"],
        "Chemistry": ["Atoms", "Reactions", "Acids & Bases"],
        "Biology": ["Cells", "Genetics", "Evolution"],
        "Computer Science": ["Algorithms", "Data Structures", "AI"]
    };

    setTimeout(() => {
        let results = topics[subject] || ["No topics found"];
        output.innerHTML = `<h3>Topics in ${subject}:</h3><ul>` +
            results.map(r => `<li>${r}</li>`).join('') + "</ul>";
    }, 1000);
}
