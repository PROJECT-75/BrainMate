# BrainMate Project

## Setup Instructions
- Upload frontend and backend folders to GitHub
- Deploy frontend to Vercel
- Deploy backend to Render
- Use `.env.example` to setup API keys securely.