
const topics = [
    { subject: "Maths", title: "Pythagoras Theorem" },
    { subject: "Physics", title: "Newton's Laws of Motion" },
    { subject: "Chemistry", title: "Periodic Table" },
    { subject: "Biology", title: "Photosynthesis" },
    { subject: "English", title: "Tenses and Grammar" },
    { subject: "History", title: "French Revolution" }
];

function searchTopics() {
    const input = document.getElementById("searchInput").value.toLowerCase();
    const results = topics.filter(t => t.title.toLowerCase().includes(input));
    displayResults(results);
}

function filterSubject(subject) {
    const results = topics.filter(t => t.subject === subject);
    displayResults(results);
}

function displayResults(results) {
    const container = document.getElementById("results");
    if (results.length === 0) {
        container.innerHTML = "<p>No topics found.</p>";
    } else {
        container.innerHTML = results.map(r => `<p><strong>${r.subject}:</strong> ${r.title}</p>`).join("");
    }
}
